# AngularTourOfHeroes

This folder contains the local installation of the [Angular CLI](https://github.com/angular/angular-cli) version 18.1.2.

## Project scaffolding

Use the `ng new` command to start creating your *Tour of Heroes* application.
